#ifndef _CONSTANTS_HPP_
#define _CONSTANTS_HPP_

const unsigned int BITSET_LEN = 8;
const unsigned int INITIAL_NUM_BUCKETS = 4;
const unsigned int MAX_BUCKET_SIZE = 2;

#endif